# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import z_res_users,z_res_company,z_account_invoice,constant,z_stock_picking,z_res_config_settings

